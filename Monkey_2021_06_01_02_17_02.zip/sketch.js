var bananaImage, ObstacleImage,ObstacleGroup;
var background, score;

function preload()
{
  backImage = loadImage("jungle.png");
  player_running=
    loadAnimation("Monkey_01.png" , "Monkey_02.png", "Monkey_03.png","Monkey_04.png", "Monkey_05.png", "Monkey_06.png","Monkey_07.png","Monkye_08.png","Monkey_09.png","Monkey_10.png")
  backImage = loadImage("Banana.png")
  
}



function setup() {
  createCanvas(400, 400);
  backgound= createSprite(400,400);
  background.addImage("Banana.png",backImage);
  
  background.velocityX = -2;
  ground.visible=false;
  
 player.addAnimation("run",player_running);
  
  
}

function draw() {
  background.reset();
  if(BananaImage.isTouching(player)){
    
  }
  switch(score){
    case 10 : player.scale=0.12;
      break;
      case 20: player.scale=0.14
      break;
      case 30: player.scale=0.16
      break;
      case 40: player.scale=0.18;
      break;
      default:break;
    
  }
  if(ObstacleGroup.isTouchin(obstacleImage)){
    obstacleImage.scale = 0.12
  }
  stroke ("white");
  textSize(20);
  fill("white");
  text("Score: " + score,500,50);}